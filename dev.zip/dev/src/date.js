var myCalendar = new MyCalendar({
	el: document.getElementById('myCalendar'),
	autoClose: false
});
myCalendar.open();