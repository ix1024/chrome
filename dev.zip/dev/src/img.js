define([
	'tabs',
	'menus',
	'chromeExtension'
], function(
	tabs,
	menus,
	chromeExtension
) {

});