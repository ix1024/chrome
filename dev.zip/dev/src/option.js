require(['options'], function(options) {
	//console.log(options);
});